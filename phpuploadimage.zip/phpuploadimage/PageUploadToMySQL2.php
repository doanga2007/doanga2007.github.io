<html>
<head>
<title>ThaiCreate.Com Tutorial</title>
</head>
<body>
<?php
	if(copy($_FILES["filUpload"]["tmp_name"],"myfile/".$_FILES["filUpload"]["name"]))
	{
		echo "Copy/Upload Complete<br>";

		//*** Insert Record ***//
		$objConnect = mysqli_connect("localhost","root","","mydatabase");
		mysqli_set_charset($objConnect,"utf8");
		
		$strSQL = "INSERT INTO files ";
		$strSQL .="(Name,FilesName) VALUES ('".$_POST["txtName"]."','".$_FILES["filUpload"]["name"]."')";
		$objQuery = mysqli_query($objConnect,$strSQL);		
	}
?>
<a href="PageUploadToMySQL3.php">View files</a>
</body>
</html>