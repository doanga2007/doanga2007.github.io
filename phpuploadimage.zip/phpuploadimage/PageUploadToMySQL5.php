<html>
<head>
<title>ThaiCreate.Com Tutorial</title>
</head>
<body>
<?php
		//*** Update Record ***//
		$objConnect = mysqli_connect("localhost","root","","mydatabase");
		mysqli_set_charset($objConnect,"utf8");

		$strSQL = "UPDATE files ";
		$strSQL .=" SET NAME = '".$_POST["txtName"]."' WHERE FilesID = '".$_GET["FilesID"]."' ";
		$objQuery = mysqli_query($objConnect,$strSQL);
	
	if($_FILES["filUpload"]["name"] != "")
	{
		if(copy($_FILES["filUpload"]["tmp_name"],"myfile/".$_FILES["filUpload"]["name"]))
		{

			//*** Delete Old File ***//			
			@unlink("myfile/".$_POST["hdnOldFile"]);
			
			//*** Update New File ***//
			$strSQL = "UPDATE files ";
			$strSQL .=" SET FilesName = '".$_FILES["filUpload"]["name"]."' WHERE FilesID = '".$_GET["FilesID"]."' ";
			$objQuery = mysqli_query($objConnect,$strSQL);	

			echo "Copy/Upload Complete<br>";

		}
	}
?>
<a href="PageUploadToMySQL3.php">View files</a>
</body>
</html>