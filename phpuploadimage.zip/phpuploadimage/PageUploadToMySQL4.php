<html>
<head>
<title>ThaiCreate.Com Tutorial</title>
</head>
<body>
<?php
	$objConnect = mysqli_connect("localhost","root","","mydatabase");
	mysqli_set_charset($objConnect,"utf8");

	$strSQL = "SELECT * FROM files WHERE FilesID = '".$_GET["FilesID"]."' ";
	$objQuery = mysqli_query($objConnect,$strSQL);
	$objResult = mysqli_fetch_array($objQuery,MYSQLI_ASSOC);
?>
	<form name="form1" method="post" action="PageUploadToMySQL5.php?FilesID=<?=$_GET["FilesID"];?>" enctype="multipart/form-data">
	Edit Picture :<br>
	Name : <input type="text" name="txtName" value="<?=$objResult["Name"];?>"><br>
	<img src="myfile/<?=$objResult["FilesName"];?>"><br>
	Picture : <input type="file" name="filUpload"><br>
	<input type="hidden" name="hdnOldFile" value="<?=$objResult["FilesName"];?>">
	<input name="btnSubmit" type="submit" value="Submit">
	</form>
</body>
</html>