<!doctype html>
<html>
<head>
  <title>ทดสอบ Tesseract.js 4</title>
</head>
<body>
<p id="status"></p>
<script src="http://localhost/ocrtest2021/tesseract.min.js"></script>
<script>
	var sta = document.getElementById("status");
    
    /* Code to crossOrigin = anonymous */
    var recogImage = new Image;
	recogImage.crossOrigin = "anonymous"; /* THIS WILL MAKE THE IMAGE CROSS-ORIGIN */
	recogImage.src = "http://localhost/ocrtest2021/test-ocr-2021.jpg";

    const worker = Tesseract.createWorker({
      logger: m => sta.innerHTML = m.status
    });
    Tesseract.setLogging(true);
    work();

    async function work() {
      await worker.load();
      await worker.loadLanguage('eng+tha');
      await worker.initialize('eng+tha');

      //let result = await worker.detect(recogImage);
      //console.log(result.data);

      let result = await worker.recognize(recogImage);
      sta.innerHTML = result.data.text;

      await worker.terminate();
    }
    
// https://www.thaicreate.com/php/forum/135293.html
</script>
</body>
</html>